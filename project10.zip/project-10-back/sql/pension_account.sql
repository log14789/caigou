SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for pension_account
-- ----------------------------
DROP TABLE IF EXISTS `pension_account`;
CREATE TABLE `pension_account`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '主键id',

  -- 在此处进行建表 sql 语句补全或使用工具创建表字段

  `create_time` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '创建时间',
  `update_time` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
