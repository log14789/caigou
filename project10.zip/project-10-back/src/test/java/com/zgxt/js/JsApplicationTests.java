package com.zgxt.js;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsApplicationTests {

    @Test
    void contextLoads() {
    }

}
