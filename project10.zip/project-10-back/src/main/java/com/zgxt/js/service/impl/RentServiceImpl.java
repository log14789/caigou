package com.zgxt.js.service.impl;

public class RentServiceImpl {
}
