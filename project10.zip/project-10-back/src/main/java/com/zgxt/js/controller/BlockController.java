package com.zgxt.js.controller;

import cn.hutool.core.lang.Dict;

import com.baidu.xuper.pb.XchainOuterClass;
import com.zgxt.js.domain.entity.ContractInvokeEntity;
import com.zgxt.js.domain.entity.ContractQueryEntity;
import com.zgxt.js.domain.entity.PensionAccount;
import com.zgxt.js.utils.SuperchainUtil;

import org.bouncycastle.util.encoders.Hex;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/chain")
public class BlockController {
    @Autowired
    SuperchainUtil superchainUtil;

    @Value("${superchain.contract.creator}")
    String contractCreator;

    @Value("${superchain.contract.name}")
    String contractName;

    // 获取区块链信息
    @RequestMapping(value = "/getBlockInformation", method = RequestMethod.GET)
    public Map<String,Object> getBlockInformation() throws UnsupportedEncodingException {
        //TODO:区块链的最新高度和最新交易Hash接口补充源码

        Map<String,Object> resMap = new HashMap<>();
        try {
            //获取到区块高度
            long blockHeight = block.getLong("height");
            System.out.println("最新区块高度："+blockHeight);

            //获取到交易Hash
            String txHashes = block.getJSONArray("txHashes");
            System.out.println("最新区块交易Hash："+txHashes);

            resMap.put("code", 200);
            resMap.put("message", "请求成功");
            resMap.put("data", null);
        } catch (Exception e) {
            e.printStackTrace();
            resMap.put("code", 500);
            resMap.put("message", "请求失败");
        }
        return resMap;
    }

  /**
     * 添加养老保险账户
     * */
    @RequestMapping(value = "/addPensionAccount", method = RequestMethod.POST)
    //TODO:此处代码补全：接收从 Web 端传输的参数（包括参保人姓名、身份证、工作单位、工作年限、工资、缴费基数）
    public Map<String,Object> addPensionAccount(...) {
        Map<String,Object> resMap = new HashMap<>();
        try {
            //TODO：此处代码补全：调用Java-SDK，运行调用智能合约 API，创建养老保险账号的钱包地址、账户余额传递给前端页面

            //TODO:此处代码补全：创建养老保险账号成功后，将获取的钱包信息进行解析，并通过数据库依赖包（mysql-connector-java-bin.jar)存储到数据库中

            resMap.put("code", 200);
            resMap.put("message", "请求成功");
            resMap.put("data", null);
        } catch (Exception e) {
            e.printStackTrace();
            resMap.put("code", 500);
            resMap.put("message", "请求失败");
        }
       
        return resMap;
    }

    // 创建账户
    @RequestMapping(value = "accountCreate", method = RequestMethod.GET)
    public Dict createAccount(@RequestParam("name") String name) {
        return superchainUtil.createContractAccount(name);
    }

    // 账户余额查询
    @RequestMapping(value="balanceQuery", method = RequestMethod.GET)
    public Dict queryBalance(@RequestParam("name") String name) {
        return superchainUtil.getAccountBalance(name);
    }

    // 合约调用(invoke)
    @RequestMapping(value = "contractInvoke", method = RequestMethod.POST)
    public Dict invokeContract(@RequestBody ContractInvokeEntity contractInvokeEntity) {

        String accountName = contractInvokeEntity.getAcountName();
        String contractName = contractInvokeEntity.getContractName();
        String funcName = contractInvokeEntity.getFuncName();
        Map<String, String> args = contractInvokeEntity.getArgs();

        return superchainUtil.invokeContract(accountName, contractName, funcName, args);
    }

    //  合约查询(query)
    @RequestMapping(value = "contractQuery", method = RequestMethod.POST)
    public Dict queryContract(@RequestBody ContractQueryEntity contractQueryEntity) {

        String accountName = contractQueryEntity.getAcountName();
        String contractName = contractQueryEntity.getContractName();
        String funcName = contractQueryEntity.getFuncName();
        Map<String, String> args = contractQueryEntity.getArgs();

        return superchainUtil.queryContract(accountName, contractName, funcName, args);
    }
}
