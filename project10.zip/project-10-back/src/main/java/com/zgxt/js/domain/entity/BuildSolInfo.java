package com.zgxt.js.domain.entity;

import lombok.Data;

@Data
public class BuildSolInfo {
    /**
     * 合约名称
     */
    private String contractName;
    /**
     * abi存放路径
     */
    private String abiPath;
    /**
     * bin存放路径
     */
    private String binPath;
}
