package com.zgxt.js.domain.entity;

import java.io.Serializable;

import lombok.Data;

@Data
public class PensionAccount implements Serializable{

    private static final long serialVersionUID=1L;

    //TODO: 在此处进行代码补全，声明养老账号实体字段，并添加 Get 和 Set 方法
}
