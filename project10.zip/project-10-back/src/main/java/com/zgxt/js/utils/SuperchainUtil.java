package com.zgxt.js.utils;

import cn.hutool.core.lang.Dict;
import com.baidu.xuper.api.Account;
import com.baidu.xuper.api.Transaction;
import com.baidu.xuper.pb.XchainOuterClass;
import org.bouncycastle.util.encoders.Hex;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.baidu.xuper.api.XuperClient;

@Service
public class SuperchainUtil {

    @Value("${superchain.keys}")
    String keyPath;
    @Value("${superchain.host}")
    String host;

    private XuperClient client;
    private synchronized XuperClient GetXuperClient(){
        if (client == null ) {
            synchronized (XuperClient.class) {
                if (client == null) {
                    client = new XuperClient(host);
                }
            }
        }
        return client;
    }

    //获取区块ID、高度、交易ID
    public  XchainOuterClass.InternalBlock getBlockchainInfo() {
        XchainOuterClass.BCStatus bcs = GetXuperClient().getBlockchainStatus("xuper");
        return bcs.getBlock();
    }

    //获取区块ID、高度、交易ID
    public Map<String,Object> getBlockchainStatus() {
        XchainOuterClass.BCStatus bcs = GetXuperClient().getBlockchainStatus("xuper");
        XchainOuterClass.InternalBlock getBlocks = bcs.getBlock();
        //获取到区块高度
        long height = getBlocks.getHeight();
        //获取到交易哈希
        List<XchainOuterClass.Transaction> transList = getBlocks.getTransactionsList();
        String lastTransactionId = new String(Hex.encode(transList.get(transList.size() - 1).getTxid().toByteArray()));

        // 创建一个空的HashMap对象，用来储存区块链高度和交易哈希
        Map<String, Object> retDict = new HashMap<>();
        retDict.put("区块高度", height);
        retDict.put("交易哈希", lastTransactionId);
        return retDict;
    }
    //    //获取区块ID、高度、交易ID
    //    public Dict getBlockchainStatus() {
    //        XchainOuterClass.BCStatus bcs = client.getBlockchainStatus("xuper");
    //        XchainOuterClass.SystemsStatus systemStatus = client.getSystemStatus();
    //        byte[] hex = Hex.encode(bcs.getBlock().getBlockid().toByteArray());
    //        String blockId = new String(hex);
    //        XchainOuterClass.InternalBlock getBlocks = bcs.getBlock();
    //        List<XchainOuterClass.Transaction> transList = getBlocks.getTransactionsList();
    //        String lastTransactionId = new String(Hex.encode(transList.get(transList.size() - 1).getTxid().toByteArray()));
    //        long height = getBlocks.getHeight();
    //        Dict retDict = new Dict();
    //        retDict.put("height", height);
    //        retDict.put("blockId", blockId);
    //        retDict.put("transactionId", lastTransactionId);
    //        return retDict;
    //    }

    /**
     * 创建超级链用户
     * */
    public Dict createContractAccount(String name){
        Account account = Account.create(keyPath);
        Map txMap = new HashMap();
        Transaction tx = GetXuperClient().createContractAccount(account, name);
        txMap.put("txId", tx.getTxid());
        txMap.put("gasUsed", tx.getGasUsed());
        txMap.put("response", tx.getContractResponse().getMessage());
        return new Dict(txMap);
    }

    /**
     * 实现合约地址间的账户转账
     * */
    public Dict transfer(String from, String to) {
        //设置From账户
        Account account = Account.create();
        account.setContractAccount(from);
        Transaction tx = GetXuperClient().transfer(account, to, BigInteger.valueOf(1000000), "1");
        Map txMap = new HashMap();
        txMap.put("txId", tx.getTxid());
        txMap.put("gasUsed", tx.getGasUsed());
        txMap.put("response", tx.getContractResponse().getMessage());
        return new Dict(txMap);
    }

    /**
     * 实现从初始账户获取xuper币
     * */
    public Dict getCoin(String to) {
        Account account = Account.create(keyPath);
        Transaction tx = GetXuperClient().transfer(account, to, BigInteger.valueOf(1000000), "1");
        Map txMap = new HashMap();
        txMap.put("txId", tx.getTxid());
        txMap.put("gasUsed", tx.getGasUsed());
        txMap.put("response", tx.getContractResponse().getMessage());
        return new Dict(txMap);
    }

    /**
     * 查询账户余额
     * */
    public Dict getAccountBalance(String name) {
        BigInteger balance = GetXuperClient().getBalance(name);
        Map resMap = new HashMap();
        resMap.put("balance", balance);
        return new Dict(resMap);
    }

    /**
     * 触发合约交易(invoke)
     * */
    public Dict invokeContract(String accountName,
                               String contractName,
                               String funcName,
                               Map<String, String> args) {
        Account account = Account.create(keyPath);
        //设置合约用户
        account.setContractAccount(accountName);

        try{
            Transaction tx = GetXuperClient().invokeEVMContract(account, contractName, funcName, args, null);
            Map resMap = new HashMap<String, String>() {
                {
                    put("txId", tx.getTxid());
                    put("message", tx.getContractResponse().getMessage());
                    put("body", tx.getContractResponse().getBodyStr());
                }
            };
            return new Dict(resMap);
        }catch (Exception e) {
            Map resMap = new HashMap<String, String>();
            resMap.put("isError", 1);
            resMap.put("msg", e.getMessage());
            return new Dict(resMap);
        }
    }

    /**
     * 查询合约功能(query)
     * */
    public Dict queryContract(String accountName,
                              String contractName,
                              String funcName,
                              Map<String, String> args) {
        Account account = Account.create(keyPath);
        //设置合约用户
        account.setContractAccount(accountName);
        Transaction tx = GetXuperClient().queryEVMContract(account, contractName, funcName, args);
        Map resMap = new HashMap<String, String>() {
            {
                put("message", tx.getContractResponse().getMessage());
                put("body", tx.getContractResponse().getBodyStr());
            }
        };
        return new Dict(resMap);
    }


}
