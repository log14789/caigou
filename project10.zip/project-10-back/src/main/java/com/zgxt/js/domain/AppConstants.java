package com.zgxt.js.domain;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConstants {

}
