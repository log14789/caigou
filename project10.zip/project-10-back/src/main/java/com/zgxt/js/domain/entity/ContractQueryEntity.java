package com.zgxt.js.domain.entity;

public class ContractQueryEntity extends ContractInvokeEntity{
}
