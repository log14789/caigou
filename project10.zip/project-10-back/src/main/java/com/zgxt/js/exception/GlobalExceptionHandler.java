package com.zgxt.js.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zgxt.js.domain.response.BaseResponse;

import java.io.IOException;

@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * 处理自定义的业务异常
     */
    @ExceptionHandler(value = FiscoException.class)
    @ResponseBody
    public BaseResponse<String> rsgsExceptionHandler(FiscoException e) {
        logger.error("发生业务异常！原因是：{}", e.getMessage());
        return new BaseResponse<>(e.getCode(), e.getMessage(), null);
    }

    /**
     * 处理自定义的业务异常
     */
    @ExceptionHandler(value = IllegalArgumentException.class)
    @ResponseBody
    public BaseResponse<String> exceptionHandler(IllegalArgumentException e) {
        logger.error("发生业务异常！原因是：{}", e.getMessage());
        return new BaseResponse<>(400, e.getMessage(), null);
    }

    /**
     * 处理自定义的业务异常
     */
    @ExceptionHandler(value = IllegalStateException.class)
    @ResponseBody
    public BaseResponse<String> exceptionHandler(IllegalStateException e) {
        logger.error("发生业务异常！原因是：{}", e.getMessage());
        return new BaseResponse<>(400, e.getMessage(), null);
    }

    /**
     * 处理空指针的异常
     */
    @ExceptionHandler(value = NullPointerException.class)
    @ResponseBody
    public BaseResponse<String> exceptionHandler(NullPointerException e) {
        logger.error("发生空指针异常！原因是:", e);
        return new BaseResponse<>(500, "服务器内部错误", null);
    }

    /**
     * 处理空指针的异常
     */
    @ExceptionHandler(value = IOException.class)
    @ResponseBody
    public BaseResponse<String> exceptionHandler(IOException e) {
        logger.error("发生空指针异常！原因是:", e);
        return new BaseResponse<>(500, "服务器内部错误", null);
    }


    /**
     * 处理其他异常
     */
    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public BaseResponse<String> exceptionHandler(Exception e) {
        logger.error("未知异常！原因是:", e);
        return new BaseResponse<>(500, "服务器内部错误", null);
    }

}
