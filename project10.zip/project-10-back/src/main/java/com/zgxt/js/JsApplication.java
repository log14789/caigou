package com.zgxt.js;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsApplication {

    public static void main(String[] args) {
        SpringApplication.run(JsApplication.class, args);
    }

}
