package com.zgxt.js.service;

import com.zgxt.js.domain.response.BaseResponse;

public interface RentService {

    BaseResponse<String> addRenter();

}

