package com.zgxt.js.domain.entity;

import lombok.Data;

@Data
public class AddAccountEntity {

    private String name; // 姓名
    private String idCard; // 身份证
    private String company; // 工作单位
    private int year; // 工作时长（年）
    private int salary; // 工资（元）
    private int baseSalary; // 缴费基数（元）
}
