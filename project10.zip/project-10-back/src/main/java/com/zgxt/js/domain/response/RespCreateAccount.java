package com.zgxt.js.domain.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class RespCreateAccount {

    @JsonProperty(value = "address")
    private String address; // 账户地址

    @JsonProperty(value = "private_key_path")
    private String privateKeyPath; // 私匙存放路径

    @JsonProperty(value = "public_key_path")
    private String publicKeyPath; // 公匙存放路径

    public RespCreateAccount() {
    }

    public RespCreateAccount(String address, String privateKeyPath, String publicKeyPath) {
        this.address = address;
        this.privateKeyPath = privateKeyPath;
        this.publicKeyPath = publicKeyPath;
    }
}
