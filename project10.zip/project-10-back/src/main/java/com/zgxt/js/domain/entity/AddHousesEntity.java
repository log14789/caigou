package com.zgxt.js.domain.entity;

import lombok.Data;

@Data
public class AddHousesEntity {

    private String homeowner;
    private String location;
    private int rentMoney;
    private int deposit;
}
