package com.zgxt.js.domain.entity;

import lombok.Data;

import java.util.Map;

@Data
public class ContractInvokeEntity {
    private String acountName;
    private String contractName;
    private String funcName;
    private Map<String, String> args;

}
