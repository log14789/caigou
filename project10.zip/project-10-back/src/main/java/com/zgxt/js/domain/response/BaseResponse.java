package com.zgxt.js.domain.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class BaseResponse<T> {
    /**
     * 状态返回码：
     * 0：请求成功
     * 1:请求失败
     */
    private Integer err;

    private String msg;

    private T data;


    public BaseResponse() {
    }

    public BaseResponse(Integer err, String message, T data) {
        this.err = err;
        this.msg = message;
        this.data = data;
    }

    /**
     * 成功
     */
    public BaseResponse<T> success() {
        return success(null);
    }

    /**
     * 成功
     */
    public BaseResponse<T> success(T data) {
        return new BaseResponse<>(0, "ok", data);
    }


    /**
     * 失败
     */
    public BaseResponse<T> error(int err, String message) {
        return new BaseResponse<>(err, message, null);
    }

    /**
     * 失败
     */
    public BaseResponse<T> error(String message) {
        return new BaseResponse<>(1, message, null);
    }

}
