package com.zgxt.js.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice
public class FiscoException extends RuntimeException {

    // 错误码
    protected int code;

    // 错误信息
    protected String message;

    public FiscoException() {
        super();
    }

    public FiscoException(String errorMsg) {
        super(errorMsg);
        this.message = errorMsg;
    }

    public FiscoException(int errorCode, String errorMsg) {
        super(errorMsg);
        this.code = errorCode;
        this.message = errorMsg;
    }

    public FiscoException(int errorCode, String errorMsg, Throwable cause) {
        super(errorMsg, cause);
        this.code = errorCode;
        this.message = errorMsg;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    @Override
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public Throwable fillInStackTrace() {
        return this;
    }
}
